﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using workview = Hyland.Unity.WorkView;

namespace LoanManagement_UnityAPI
{
    public partial class ImportDocument : System.Web.UI.Page
    {
        private Hyland.Unity.Application _application = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }

                if (!IsPostBack)
                {

                    Random random = new Random();
                    string randomNumber = string.Join(string.Empty, Enumerable.Range(0, 10).Select(number => random.Next(0, 8).ToString()));
                    string randomNumber2 = string.Join(string.Empty, Enumerable.Range(0, 10).Select(number => random.Next(0, 8).ToString()));

                    this.txtFirstName1.Text = "Sarah";
                    this.txtLastName1.Text = "Smith";
                    this.txtSSN1.Text = randomNumber;
                    
                    this.txtFirstName2.Text = "John";
                    this.txtLastName2.Text = "Maverick";
                    this.txtSSN2.Text = randomNumber2;

                    this.txtLoanAmt.Text = 2214521.ToString();
                    
                    LoadAccounts();
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        private void LoadAccounts()
        {
            if (_application == null)
            {
                throw new Exception("Not Connected to OnBase!");
            }

            workview.Application wvApplication = _application.WorkView.Applications.Find("UnityAPITraining");
            if (wvApplication == null)
            {
                throw new Exception("Could not find workview application!");
            }

            workview.Class accountsClass = wvApplication.Classes.Find("Account");
            if (accountsClass == null)
            {
                throw new Exception("Could not find the class for Account in workview");
            }

            workview.DynamicFilterQuery dynamicFilterQuery = accountsClass.CreateDynamicFilterQuery();
            workview.FilterQueryResultItemList queryResults = dynamicFilterQuery.Execute(100);

            foreach (workview.FilterQueryResultItem queryResult in queryResults)
            {
                workview.Object resultObject = accountsClass.GetObjectByID(queryResult.ObjectID);
                if (resultObject == null)
                {
                    throw new Exception("Cannot find object in result set.");
                }

               string val = WorkviewHelperMethods.GetAttributeValueAsAlpha(resultObject, "AccountNumber");
               if (!string.IsNullOrEmpty(val))
               {
                   dpAccounts.Items.Add(val);
               }
            }
        }

        protected void btnImportDocument_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath = loanAppFileUpload.PostedFile.FileName;

                if (string.IsNullOrEmpty(txtSSN1.Text))
                {
                    throw new Exception("Signer 1 SSN must be filled in"); 
                }
                if (!string.IsNullOrEmpty(txtFirstName2.Text) || !string.IsNullOrEmpty(txtLastName2.Text))
                {
                    if (string.IsNullOrEmpty(txtSSN2.Text))
                    {
                        throw new Exception("If entering secondary signer. Please fill in Signer 2 SSN."); 
                    }
                }
                
                

                Hyland.Unity.KeywordType ssnKeyType = _application.Core.KeywordTypes.Find("SSN");
                Hyland.Unity.KeywordType firstNameKeyType = _application.Core.KeywordTypes.Find("First Name");
                Hyland.Unity.KeywordType lastNameKeyType = _application.Core.KeywordTypes.Find("Last Name");

                List<Hyland.Unity.Keyword> signer1KeywordList = new List<Hyland.Unity.Keyword>();
                Hyland.Unity.Keyword ssnkeyword1 = ssnKeyType.CreateKeyword(txtSSN1.Text);
                Hyland.Unity.Keyword fnkeyword1 = firstNameKeyType.CreateKeyword(txtFirstName1.Text);
                Hyland.Unity.Keyword lnkeyword1 = lastNameKeyType.CreateKeyword(txtLastName1.Text);
                signer1KeywordList.Add(ssnkeyword1);
                signer1KeywordList.Add(fnkeyword1);
                signer1KeywordList.Add(lnkeyword1);

                List<Hyland.Unity.Keyword> signer2KeywordList = new List<Hyland.Unity.Keyword>();
                Hyland.Unity.Keyword ssnkeyword2 = ssnKeyType.CreateKeyword(txtSSN2.Text);
                Hyland.Unity.Keyword fnkeyword2 = firstNameKeyType.CreateKeyword(txtFirstName2.Text);
                Hyland.Unity.Keyword lnkeyword2 = lastNameKeyType.CreateKeyword(txtLastName2.Text);
                signer2KeywordList.Add(ssnkeyword2);
                signer2KeywordList.Add(fnkeyword2);
                signer2KeywordList.Add(lnkeyword2);


                UnityAPI.Archival archival = new UnityAPI.Archival(_application);
                long docID = archival.StoreNewLoanDocument(filePath, dpAccounts.SelectedValue, txtLoanAmt.Text, signer1KeywordList, signer2KeywordList);
                if (docID > 0)
                {
                    Responselbl.Text = "Document successfully imported into OnBase! New Document ID: " + docID;
                    responseDiv.Visible = true;
                }
                else
                {
                    Responselbl.Text = "Document was not successfully imported into OnBase.";
                    responseDiv.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        protected void btnClearForm_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/ImportDocument.aspx");
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }
    }
}