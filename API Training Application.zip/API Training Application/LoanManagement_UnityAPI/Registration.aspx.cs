﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Hyland.Unity;
using UnityAPI;

namespace LoanManagement_UnityAPI
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRequestAccount_Click(object sender, EventArgs e)
        {
            try
            {
                //connect with generic account for new account requests
                Connection connection = new Connection();
                using (Hyland.Unity.Application app = connection.Connect("MANAGER", "PASSWORD"))
                {
                    Archival archival = new Archival(app);
                    long docID = archival.StoreNewUserUnityForm(txtFullName.Text, managerName.SelectedValue);
                    if (docID > 0)
                    {
                        Responselbl.Text = "Your new user request has been submitted. New Document ID: " + docID;
                        responseDiv.Visible = true;
                    }
                    else
                    {
                        Responselbl.Text = "Your new user request was not succesful.";
                        responseDiv.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }
    }
}