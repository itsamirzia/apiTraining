﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using UnityAPI;
using Hyland.Unity;
using workview = Hyland.Unity.WorkView;

namespace LoanManagement_UnityAPI
{
    public partial class Accounts : System.Web.UI.Page
    {

        //Global unity application object
        private Hyland.Unity.Application _application = null;
        private List<string> AccountNumbers = new List<string>(); 

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }
                if (!IsPostBack)
                {

                    DataTable dt = GetAccounts();
                    AccountsGrid.DataSource = dt;
                    AccountsGrid.DataBind();
                    PopulateDocTypes();
                    PopulateAccountNumbers(); 

                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        private void PopulateAccountNumbers()
        {
            dlAccountNumbers.Items.Add(""); 
            foreach (string acctNum in AccountNumbers)
            {
                dlAccountNumbers.Items.Add(acctNum); 
            }
        }

        private void PopulateDocTypes()
        {
            
                ConfigurationItems items = new ConfigurationItems(_application);
                foreach (string dtName in items.GetDocumentTypes())
                {
                    DocumentType docType = FindDTByName(dtName);
                    dlDocumentTypes.Items.Add(docType.Name);

                    
                }
           

        }

        private DocumentType FindDTByName(string documentTypeName)
        {
            DocumentType dt = _application.Core.DocumentTypes.Find(documentTypeName);
            if (dt == null)
            {
                throw new Exception("Could not find document type with name: " + documentTypeName);
            }

            return dt;

        }

        private DataTable GetAccounts()
        {
            DataTable dataTable = new DataTable(); 
            try
            {
                if (_application == null)
                {
                    throw new Exception("Not Connected to OnBase!");
                }

                workview.Application wvApplication = _application.WorkView.Applications.Find("UnityAPITraining");
                if (wvApplication == null)
                {
                    throw new Exception("Could not find workview application!");
                }

                workview.Class accountsClass = wvApplication.Classes.Find("Account");
                if (accountsClass == null)
                {
                    throw new Exception("Could not find the class for Account in workview");
                }


            
                List<string> columns = new List<string>(); 
                foreach (workview.Attribute attribute in accountsClass.Attributes)
                {
                    dataTable.Columns.Add(new DataColumn(attribute.Name, typeof(string))); 
                    columns.Add(attribute.Name); 
                }


                workview.DynamicFilterQuery dynamicFilterQuery = accountsClass.CreateDynamicFilterQuery();
                workview.FilterQueryResultItemList queryResults = dynamicFilterQuery.Execute(100);

               
            
                foreach (workview.FilterQueryResultItem queryResult in queryResults)
                {
                    workview.Object resultObject = accountsClass.GetObjectByID(queryResult.ObjectID);
                    if (resultObject == null)
                    {
                        throw new Exception("Cannot find object in result set.");
                    }

                    List<string> values = new List<string>(); 
                    foreach(string attr in columns)
                    {
                        string val = WorkviewHelperMethods.GetAttributeValueAsAlpha(resultObject, attr);
                        values.Add(val);
                        if (string.Compare(attr, "AccountNumber", true) == 0)
                        { 
                            if(!AccountNumbers.Contains(val))
                            {
                                AccountNumbers.Add(val); 
                            }
                        }
                    }

                    object[] rowValues = values.ToArray<object>();
                    dataTable.Rows.Add(rowValues); 
                   
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
            return dataTable;

        }

        protected void btnQueryAccountDocuments_Click(object sender, EventArgs e)
        {
            try
            {

                string selectedDocType = string.Empty;
                string acctNumber = string.Empty;

                selectedDocType = dlDocumentTypes.SelectedItem.Value;
                acctNumber = dlAccountNumbers.SelectedItem.Value;

                if (string.IsNullOrEmpty(selectedDocType))
                {
                    throw new Exception("Document Type must be selected!"); 
                }
                
                GetAccountDocuments acctDocs = new GetAccountDocuments(_application);
                DocumentList docList = null;
                if (!string.IsNullOrEmpty(acctNumber))
                {
                    docList = acctDocs.GetDocumentsForAccount(selectedDocType, acctNumber);
                }
                else
                {
                   
                }

                Session["accountDocList"] = docList;

                Response.Redirect("~/AccountDocuments.aspx"); 
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        private void PopulateDocumentGrid()
        { 
            
        }
    }
}