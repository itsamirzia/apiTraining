﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Hyland.Unity;
using System.Text;


namespace LoanManagement_UnityAPI
{
    public partial class UpdateKeywords : System.Web.UI.Page
    {

        private Hyland.Unity.Application _application = null;
        private Document _document = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }
                string docID = Request.QueryString["docID"] as string;
                if (!string.IsNullOrEmpty(docID))
                {
                    long lngDocID = -1;
                    if (!long.TryParse(docID, out lngDocID))
                    {
                        throw new Exception("Could not determine docID");
                    }
                    Document document = _application.Core.GetDocumentByID(lngDocID);
                    if (document == null)
                    {
                        throw new Exception("Could not find document with id of :" + docID);
                    }
                    _document = document;
                }

                BuildTable(_document);


                //UnityAPI.ValidateKeywords validate = new UnityAPI.ValidateKeywords(_application);
                //decimal amount = 0;
                //if (!validate.AmountAboveThreshold(_document.ID, out amount))
                //{
                //    btnSetApprovalStatus.Visible = false;
                //}

            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        private void BuildTable(Document document)
        {


            foreach (KeywordRecord record in document.KeywordRecords)
            {

                if (record.KeywordRecordType.Name == "Signer Information")
                {
                    Table table = new Table();
                    foreach (Keyword keyword in record.Keywords)
                    {
                        TableRow tr = new TableRow();
                        TableCell td1 = new TableCell();
                        TableCell td2 = new TableCell();

                        string displayname = keyword.KeywordType.Name;
                        string keywordTypeID = keyword.KeywordType.ID.ToString();
                        string value = string.Empty;
                        if (!keyword.IsBlank)
                        {
                            value = keyword.AlphaNumericValue;
                        }

                        Label lblName = new Label();
                        lblName.ID = "lbl_" + keywordTypeID + "_" + record.ID;
                        lblName.Text = displayname;

                        td1.Controls.Add(lblName);
                        tr.Controls.Add(td1);


                        if (string.Compare(displayname, "SSN", true) != 0)
                        {
                            TextBox txtBoxValue = new TextBox();
                            txtBoxValue.ID = "txtValue_" + keywordTypeID + "_" + record.ID;
                            txtBoxValue.Text = value;
                            td2.Controls.Add(txtBoxValue);

                        }
                        else
                        {
                            Label lblValue = new Label();
                            lblValue.ID = "lblValue_" + keywordTypeID + "_" + record.ID;
                            lblValue.Text = value;
                            td2.Controls.Add(lblValue);
                        }
                        tr.Controls.Add(td2);
                        table.Controls.Add(tr);
                    }

                    StringBuilder str = new StringBuilder();
                    str.Append("<h3>");
                    str.Append("Signer Information");
                    str.Append("</h3>");
                    str.Append("<div>");

                    LiteralControl literal = new LiteralControl();
                    literal.Text = str.ToString();
                    profile.Controls.Add(literal);
                    profile.Controls.Add(table);
                    LiteralControl literal2 = new LiteralControl();
                    literal2.Text = "</div>";
                    profile.Controls.Add(literal2);
                }
                else if (record.KeywordRecordType.RecordType == RecordType.StandAlone)
                {
                    Table table = new Table();
                    foreach (Keyword keyword in record.Keywords)
                    {
                        TableRow tr = new TableRow();
                        TableCell td1 = new TableCell();
                        TableCell td2 = new TableCell();

                        string displayname = keyword.KeywordType.Name;
                        string keywordTypeID = keyword.KeywordType.ID.ToString();
                        string value = string.Empty;
                        if (!keyword.IsBlank & keyword.Value != null)
                        {
                            value = keyword.Value.ToString();
                        }

                        Label lblName = new Label();
                        lblName.ID = "lbl_" + keywordTypeID + "_" + record.ID;
                        lblName.Text = displayname;

                        td1.Controls.Add(lblName);
                        tr.Controls.Add(td1);

                        Label lblValue = new Label();
                        lblValue.ID = "lblValue_" + keywordTypeID + "_" + record.ID;
                        lblValue.Text = value;
                        td2.Controls.Add(lblValue);

                        tr.Controls.Add(td2);
                        table.Controls.Add(tr);
                    }


                    StringBuilder str = new StringBuilder();
                    str.Append("<h3>");
                    str.Append("Stand Alone Keywords");
                    str.Append("</h3>");
                    str.Append("<div>");

                    LiteralControl literal = new LiteralControl();
                    literal.Text = str.ToString();
                    profile.Controls.Add(literal);
                    profile.Controls.Add(table);
                    LiteralControl literal2 = new LiteralControl();
                    literal2.Text = "</div>";
                    profile.Controls.Add(literal2);

                }

            }

        }


        protected void btnUpdateMIKG_Click(object sender, EventArgs e)
        {
            try
            {

                UnityAPI.UpdateKeywords updateKeywords = new UnityAPI.UpdateKeywords(_application);
                foreach (KeywordRecord record in _document.KeywordRecords)
                {
                    if (record.KeywordRecordType.Name == "Signer Information")
                    {

                        string SSN = string.Empty;
                        //find SSN seperately because it's the identifier
                        Keyword ssnKeyword = record.Keywords.Find("SSN");
                        if (ssnKeyword == null)
                        {
                            throw new Exception("Could not find SSN within the keyword record.");
                        }

                        if (ssnKeyword.IsBlank)
                        {
                            throw new Exception("This document contains a keyword record without an SSN.");
                        }

                        SSN = ssnKeyword.AlphaNumericValue;

                        foreach (Keyword keyword in record.Keywords)
                        {
                            string displayname = keyword.KeywordType.Name;
                            string keywordTypeID = keyword.KeywordType.ID.ToString();
                            string value = string.Empty;
                            if (!keyword.IsBlank)
                            {
                                value = keyword.AlphaNumericValue;
                            }

                            if (string.Compare(displayname, "SSN", true) != 0)
                            {
                                //check to see if the corresponding input value is equal to the keyword value. if so update the keyword in the keyword record. naming = lblValue_displayName_record id
                                string controlName = "txtValue_" + keywordTypeID + "_" + record.ID.ToString();

                                TextBox textBox = (TextBox)profile.FindControl(controlName);
                                if (textBox == null)
                                {
                                    throw new Exception("Could convert control to textbox with name of: " + controlName);
                                }
                                string newValue = textBox.Text;

                                if (string.Compare(value, newValue, true) != 0)
                                {
                                    updateKeywords.UpdateSignerInfo(_document.ID, SSN, displayname, newValue);
                                    Responselbl.Text = "Your update was saved.";
                                    responseDiv.Visible = true;
                                }

                            }
                        }
                    }
                }



            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        protected void btnSetApprovalStatus_Click(object sender, EventArgs e)
        {
            try
            {
                if (_document == null)
                {
                    throw new Exception("Document cannot be null.");
                }

                UnityAPI.ValidateKeywords validate = new UnityAPI.ValidateKeywords(_application);
                decimal amount = 0;

                UnityAPI.UpdateKeywords updateKeywords = new UnityAPI.UpdateKeywords(_application);
                updateKeywords.Approve(_document.ID);
                Responselbl.Text = "Your approval was saved.";
                responseDiv.Visible = true;


                StringBuilder sbScript = new StringBuilder();

                sbScript.Append("<script language='JavaScript' type='text/javascript'>\n");
                sbScript.Append("<!--\n");
                sbScript.Append(this.GetPostBackEventReference(this, "PBArg") + ";\n");
                sbScript.Append("// -->\n");
                sbScript.Append("</script>\n");

                this.RegisterStartupScript("AutoPostBackScript", sbScript.ToString());

            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }




    }
}