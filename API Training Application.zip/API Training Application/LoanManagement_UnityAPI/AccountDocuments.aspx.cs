﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Hyland.Unity;
using UnityAPI;


namespace LoanManagement_UnityAPI
{
    public partial class AccountDocuments : System.Web.UI.Page
    {
        private Hyland.Unity.Application _application = null;
        private DocumentList _documents = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }

                _documents = Session["accountDocList"] as DocumentList;

                if (_documents == null)
                {
                    Response.Redirect("~/Accounts.aspx");
                }

                if (!IsPostBack)
                {

                    if (_documents.Count == 0)
                    {
                        //no documents, don't show grid. 
                        noDocsDiv.Visible = true;
                        AccountDocumentsGrid.Visible = false;
                        filterDiv.Visible = false;
                    }
                    else
                    {
                        noDocsDiv.Visible = false;
                        filterDiv.Visible = true;
                        AccountDocumentsGrid.Visible = true;
                        PopulateDocumentGrid();


                    }

                }

                foreach (GridViewRow row in AccountDocumentsGrid.Rows)
                {
                    string docID = row.Cells[1].Text;

                    LinkButton lb = new LinkButton();
                    lb.CommandArgument = docID;
                    lb.CommandName = "Update Keywords";
                    lb.Text = "Update Keywords";

                    row.Cells[0].Controls.Add((Control)lb);
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        private void PopulateDocumentGrid()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add(new DataColumn("Document ID", typeof(string)));
            dataTable.Columns.Add(new DataColumn("Document Name", typeof(string)));


            foreach (Document doc in _documents)
            {
                List<string> values = new List<string>();
                values.Add(doc.ID.ToString());
                values.Add(doc.Name.ToString());
                object[] rowValues = values.ToArray<object>();
                dataTable.Rows.Add(rowValues);
            }


            AccountDocumentsGrid.DataSource = dataTable;
            AccountDocumentsGrid.DataBind();



        }

        private void PopulateDocumentGrid_Filter(Dictionary<Document, string> documents, string filterColumnName)
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add(new DataColumn("Document ID", typeof(string)));
            dataTable.Columns.Add(new DataColumn("Document Name", typeof(string)));
            dataTable.Columns.Add(new DataColumn(filterColumnName, typeof(string)));

            foreach (KeyValuePair<Document, string> kvp in documents)
            {
                Document doc = kvp.Key;
                List<string> values = new List<string>();
                values.Add(doc.ID.ToString());
                values.Add(doc.Name.ToString());
                values.Add(kvp.Value);

                object[] rowValues = values.ToArray<object>();
                dataTable.Rows.Add(rowValues);
            }

            AccountDocumentsGrid.DataSource = dataTable;
            AccountDocumentsGrid.DataBind();
        }

        protected void btnCheckLoanAmounts_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<Document, string> docs = new Dictionary<Document, string>();
                foreach (Document doc in _documents)
                {
                    ValidateKeywords validate = new ValidateKeywords(_application);
                    decimal amount = 0;
                    if (validate.AmountAboveThreshold(doc.ID))
                    {
                        foreach (KeywordRecord rec in this._application.Core.GetDocumentByID(doc.ID).KeywordRecords)
                        {
                            foreach (Keyword key in rec.Keywords)
                            {
                                if (key.KeywordType.Name == "Loan Amount")
                                {
                                    amount = key.CurrencyValue;
                                    docs.Add(doc, amount.ToString());
                                }
                            }                     
                        }
                    }

                    PopulateDocumentGrid_Filter(docs, "Loan Amount");
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        protected void btnCheckSignerInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<Document, string> docs = new Dictionary<Document, string>();
                foreach (Document doc in _documents)
                {
                    ValidateKeywords validate = new ValidateKeywords(_application);
                    int numInvalid = validate.SignerInfoMissing(doc.ID);
                    if (numInvalid > 0)
                    {
                        docs.Add(doc, numInvalid.ToString());
                    }
                }

                PopulateDocumentGrid_Filter(docs, "Number of Invalid Signer Records");

            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }


        protected void btnSaveDocuments_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (GridViewRow row in AccountDocumentsGrid.Rows)
                {
                    if (((CheckBox)row.FindControl("ckSaveOutDocument")).Checked)
                    {
                        string providerName = "Default";
                        DropDownList dropDown = (DropDownList)row.FindControl("dropDownProvider");
                        if (dropDown != null)
                        {
                            providerName = dropDown.SelectedValue;
                        }

                        string id = row.Cells[1].Text;
                        long docID = long.Parse(id);
                        Document document = _application.Core.GetDocumentByID(docID);
                        SaveOutDocument saveDoc = new SaveOutDocument(_application);
                        saveDoc.SaveDocument(document, providerName);
                    }
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        protected void UpdateKeywords(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Update Keywords")
                {
                    string documentid = e.CommandArgument as string;
                    string updateKeywordsScript = "<script> window.open(\"" + "http://localhost:8275/UpdateKeywords.aspx?docID=" + documentid + "\", \"name\", \"toolbar=no,titlebar=no,status=no,menubar=no,location=right,scrollbars=no,resizable=no,height=250,width=600\", \"\");</script>";
                    //pop open keyword update window for document 
                    ClientScript.RegisterStartupScript(this.GetType(), "newWindow", updateKeywordsScript);
                }
                else if (e.CommandName == "Import Revision")
                {
                    string documentid = e.CommandArgument as string;
                    string importRevScript = "<script> window.open(\"" + "http://localhost:8275/ImportLoanRevision.aspx?docID=" + documentid + "\", \"name\", \"toolbar=no,titlebar=no,status=no,menubar=no,location=right,scrollbars=no,resizable=no,height=250,width=600\", \"\");</script>";
                    //pop open keyword update window for document 
                    ClientScript.RegisterStartupScript(this.GetType(), "newWindow", importRevScript);
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;

            }
        }

        protected void AccountDocuments_RowDataBind(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.DataItem != null)
            {


            }
        }
    }
}