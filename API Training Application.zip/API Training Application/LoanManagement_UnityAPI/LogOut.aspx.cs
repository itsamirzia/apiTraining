﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UnityAPI;

namespace LoanManagement_UnityAPI
{
    public partial class LogOut : System.Web.UI.Page
    {
        private Hyland.Unity.Application _application = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application != null)
                {
                    //Dispose will call disconnect, set the session variable to null
                    Connection connection = new Connection();
                    connection.Disconnect(_application);
                    if (_application != null)
                    {
                        _application.Dispose();
                    }
                    Session["UnityApplication"] = null;
                    Response.Redirect("~/SignIn.aspx");
                }

            }
            catch (Exception)
            { }
        }
    }
}