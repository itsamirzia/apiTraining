﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Hyland.Unity;
using UnityAPI;
using System.Data;
using workview = Hyland.Unity.WorkView;

namespace LoanManagement_UnityAPI
{
    public partial class AdvancedDocumentSearch : System.Web.UI.Page
    {
        private Hyland.Unity.Application _application = null;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }


               // if (!IsPostBack)
              //  {
                    noDocsDiv.Visible = false;
                    AccountDocumentsGrid.Visible = true;
                    PerformCQAdvancedQuery();
                    AdvancedDTQuery(); 
              //  }
                //else
                //{
                //    AdvancedDTQuery();
                //}

                
                
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        private void PerformCQAdvancedQuery()
        {
            try
            {
                AdvancedQuery advancedQuery = new AdvancedQuery(_application);
                List<Keyword> keywordList = new List<Keyword>();
                KeywordType keyType = _application.Core.KeywordTypes.Find("Loan Account #");
                keywordList.Add(keyType.CreateKeyword("4"));
                keywordList.Add(keyType.CreateKeyword("5"));
                        
                DataTable dataTable = advancedQuery.AdvancedDocumentQuery("Advanced Document Query", keywordList);
                AccountDocumentsGrid.DataSource = dataTable;
                AccountDocumentsGrid.DataBind();

                foreach (GridViewRow row in AccountDocumentsGrid.Rows)
                {
                    string docID = row.Cells[0].Text;
                    row.Cells[0].Text = docID.ToString();
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
            
        }

        private void AdvancedDTQuery()
        {
            AdvancedQuery advancedQuery = new AdvancedQuery(_application);

            //loop through all accounts: 
            List<Keyword> keywordList  = GetAccountNumbers();
            KeywordType keywordType = _application.Core.KeywordTypes.Find("Last Name");
            List<Keyword> MIKG1keywordList = new List<Keyword>();
            MIKG1keywordList.Add(keywordType.CreateKeyword("Anderson"));
            List<Keyword> MIKG2keywordList = new List<Keyword>();
            MIKG2keywordList.Add(keywordType.CreateKeyword("Adams"));

            DataTable dataTable = advancedQuery.AdvancedDocumentQuery("Loan Application", keywordList, MIKG1keywordList, MIKG2keywordList);
            dtAdvancedDocSearchGrid.DataSource = dataTable;
            dtAdvancedDocSearchGrid.DataBind();

            foreach (GridViewRow row in dtAdvancedDocSearchGrid.Rows)
            {
                string docID = row.Cells[0].Text;
                row.Cells[0].Text = docID.ToString();

            }
        }
        

        protected void btnDTAdvancedQuery_Click(object sender, EventArgs e)
        {
            try
            {
                AdvancedDTQuery(); 
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        private List<Keyword> GetAccountNumbers()
        {
            List<Keyword> keywordList = new List<Keyword>();
            KeywordType keyType = _application.Core.KeywordTypes.Find("Loan Account #");
            workview.Application wvApplication = _application.WorkView.Applications.Find("UnityAPITraining");
            if (wvApplication == null)
            {
                throw new Exception("Could not find workview application!");
            }

            workview.Class accountsClass = wvApplication.Classes.Find("Account");
            if (accountsClass == null)
            {
                throw new Exception("Could not find the class for Account in workview");
            }

            workview.DynamicFilterQuery dynamicFilterQuery = accountsClass.CreateDynamicFilterQuery();
            workview.FilterQueryResultItemList queryResults = dynamicFilterQuery.Execute(100);

            foreach (workview.FilterQueryResultItem queryResult in queryResults)
            {
                workview.Object resultObject = accountsClass.GetObjectByID(queryResult.ObjectID);
                if (resultObject == null)
                {
                    throw new Exception("Cannot find object in result set.");
                }

                string val = WorkviewHelperMethods.GetAttributeValueAsAlpha(resultObject, "AccountNumber");
                if (!string.IsNullOrEmpty(val))
                {
                    Keyword key = keyType.CreateKeyword(val);
                    keywordList.Add(key); 
                }

            }
            return keywordList; 
        }

    }
}