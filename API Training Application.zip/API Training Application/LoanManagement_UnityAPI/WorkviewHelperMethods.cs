﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Hyland.Unity;
using workview = Hyland.Unity.WorkView;

namespace LoanManagement_UnityAPI
{
    internal static class WorkviewHelperMethods
    {
        /// <summary>
        /// Retrieves any attribute as a string
        /// </summary>
        /// <param name="obj">Workview object</param>
        /// <param name="attrName">The name of the attribute to find</param>
        /// <returns>blank string if no value. If value it returns the attribute value as a string.</returns>
        internal static string GetAttributeValueAsAlpha(workview.Object obj, string attrName)
        {
            string value = string.Empty;
            workview.AttributeValue wvAttribute = obj.AttributeValues.Find(attrName);
            if (wvAttribute != null)
            {
                if (wvAttribute.HasValue)
                {
                    value = wvAttribute.Value.ToString();
                }
            }

            return value;
        }
    }
}
