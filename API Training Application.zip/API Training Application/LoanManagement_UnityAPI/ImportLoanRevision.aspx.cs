﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Hyland.Unity;
using UnityAPI;

namespace LoanManagement_UnityAPI
{
    public partial class ImportLoanRevision : System.Web.UI.Page
    {
        private Hyland.Unity.Application _application = null;
        private Document _document = null; 

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                _application = Session["UnityApplication"] as Hyland.Unity.Application;
                if (_application == null)
                {
                    Response.Redirect("~/SignIn.aspx");
                }
                string docID = Request.QueryString["docID"] as string;
                if (!string.IsNullOrEmpty(docID))
                {
                    long lngDocID = -1;
                    if (!long.TryParse(docID, out lngDocID))
                    {
                        throw new Exception("Could not determine docID");
                    }
                    Document document = _application.Core.GetDocumentByID(lngDocID);
                    if (document == null)
                    {
                        throw new Exception("Could not find document with id of :" + docID);
                    }
                    _document = document;
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }

        protected void btnStoreRevision_Click(object sender, EventArgs e)
        {
            try
            {
                FileType fileType = null; 
                switch (dropDownFileType.SelectedValue)
                { 
                    case "Image":
                        fileType = _application.Core.FileTypes.Find("Image File Format"); 
                        break;
                    case "PDF":
                        fileType = _application.Core.FileTypes.Find("PDF"); 
                        break;
                    default:
                        fileType = _application.Core.FileTypes.Find("Image File Format");
                        break;
                        
                }

                if (fileType == null)
                {
                    throw new Exception("Could not find file format for : " + dropDownFileType.SelectedValue); 
                }

            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true;
            }
        }
    }
}