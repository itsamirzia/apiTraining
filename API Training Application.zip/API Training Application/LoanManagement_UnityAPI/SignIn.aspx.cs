﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UnityAPI;
using Hyland.Unity;

namespace LoanManagement_UnityAPI
{
    public partial class SignIn : System.Web.UI.Page
    {

        //Global unity application object
        private Hyland.Unity.Application _application = null; 

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    _application = Session["UnityApplication"] as Hyland.Unity.Application;
                    if (_application != null)
                    {
                        Response.Redirect("Accounts.aspx");  
                    }
                }
            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    throw new Exception("Please enter both a username and password.");
                }

                Connection connection = new Connection();
                _application = connection.Connect(txtUsername.Text, txtPassword.Text);
                if (_application == null)
                {
                    throw new Exception("There was an error in attempting to sign in. Please contact your administrator.");
                }

                //Store the application object in session
                Session["UnityApplication"] = _application; 

                _application.Diagnostics.WriteIf(Diagnostics.DiagnosticsLevel.Verbose, string.Format("Connected to OnBase! Session ID: {0} for user {1}",
                    _application.SessionID, txtUsername.Text));

                Response.Redirect("~/Accounts.aspx");
               


            }
            catch (Exception ex)
            {
                Responselbl.Text = "An error occurred! " + ex.Message;
                responseDiv.Visible = true; 
            }
            
        }
    }
}