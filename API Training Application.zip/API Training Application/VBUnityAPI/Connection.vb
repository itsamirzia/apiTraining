﻿
Imports Hyland.Unity

Public Class Connection
        Private g_datasource As String = "OnBase"
        Private g_url As String = "http://localhost/AppServer/Service.asmx"

        Public Function Connect(username As String, password As String) As Hyland.Unity.Application
            Try
                Dim authProps As OnBaseAuthenticationProperties = Hyland.Unity.Application.CreateOnBaseAuthenticationProperties(g_url, username, password, g_datasource)
                Dim app As Hyland.Unity.Application = Hyland.Unity.Application.Connect(authProps)
                Return app
            Catch ex As InvalidLoginException
                Throw New Exception("The credentials entered are invalid.", ex)
            Catch ex As AuthenticationFailedException
                Throw New Exception("Authentication failed.", ex)
            Catch ex As MaxConcurrentLicensesException
                Throw New Exception("All licenses are currently in use, please try again later.", ex)
            Catch ex As NamedLicenseNotAvailableException
                Throw New Exception("Your license is not availble, please insure you are logged out of other OnBase clients.", ex)
            Catch ex As SystemLockedOutException
                Throw New Exception("The system is currently locked, please try back later.", ex)
            Catch ex As UnityAPIException
                Throw New Exception("There was an unhandled exception with the Unity API.", ex)
            Catch ex As Exception
                Throw New Exception("There was an unhandled exception.", ex)
            End Try
        End Function

        Public Sub Disconnect(app As Hyland.Unity.Application)
            app.Diagnostics.Write("")
        End Sub
End Class