﻿
Imports Hyland.Unity
Imports Hyland.Unity.Extensions

Public Class UpdateKeywords
        Private app As Hyland.Unity.Application = Nothing

        Public Sub Approve(DocumentID As Long)
            Dim keywordValue As String = "Approved"
            Try
                ' Get the document from the core using ID. The Document ID is passed in. Check for null.
                Dim doc As Document = app.Core.GetDocumentByID(DocumentID)
                If doc Is Nothing Then
                    Throw New Exception("Could not find document by id: " + DocumentID)
                End If
                ' Get the document type from the document object.
                Dim docType As DocumentType = doc.DocumentType
            ' Find the "Status" keyword type from the document type HINT: Use the FindKeywordType method from the KeywordRecordTypeList. Check for null.
            Dim statusKeyType As KeywordType = docType.KeywordRecordTypes.FindKeywordType("Status")
                If statusKeyType Is Nothing Then
                    Throw New Exception("The Keyword Type 'Status' could not be found or is not on the document type with name of: " + docType.Name)
                End If
                ' Create a keyword of this type with the value "Approved". Use the TryCreateKeyword extension method.
                Dim statusKeyword As Keyword = Nothing
                If Not statusKeyType.TryCreateKeyword(keywordValue, statusKeyword) Then
                    Throw New Exception("Account number keyword could not be created.")
                End If
                ' Create the KeywordModifier from the document.
                Dim keyMod As KeywordModifier = doc.CreateKeywordModifier()
                ' Find the keyword record that contains our keyword type.
                Dim keyRec As KeywordRecord = doc.KeywordRecords.Find(statusKeyType)
                ' If the keyword record is not null.
                If keyRec IsNot Nothing Then
                    ' Find the old keyword from the record of the keyword type.
                    Dim oldStatus As Keyword = keyRec.Keywords.Find(statusKeyType)
                    ' Update the keyword.
                    keyMod.UpdateKeyword(oldStatus, statusKeyword)
                Else
                    ' Else if the keyword record is null.
                    ' Add the new keyword.
                    keyMod.AddKeyword(statusKeyword)
                End If
                ' Lock the document. (Use a using statement to clean up lock.)
                Using documentLock As DocumentLock = doc.LockDocument()
                    ' Check if the lock status is Already Locked (DocumentLockStatus enum).
                    If documentLock.Status = DocumentLockStatus.AlreadyLocked Then
                        Throw New Exception("Document lock could not be obtained, lock obtained by another user or process.")
                    End If
                    ' If not locked, apply the changes to the database.
                    keyMod.ApplyChanges()
                End Using


            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Sub




        Public Sub UpdateSignerInfo(DocumentID As Long, SSNValue As String, FieldToUpdate As String, NewValue As String)
            Try
                ' Find the KeywordRecordType for "Signer Information" from the Core. Check for null.
                Dim keyRecType As KeywordRecordType = app.Core.KeywordRecordTypes.Find("Signer Information")
                If keyRecType Is Nothing Then
                    Throw New Exception("Keyword Record Type 'Signer Information' could not be found.")
                End If
                ' Find the KeywordType for FieldToUpdate from the KeywordRecordType. Check for null.
                Dim keyType As KeywordType = keyRecType.KeywordTypes.Find(FieldToUpdate)
                If keyType Is Nothing Then
                    Throw New Exception((Convert.ToString("The Keyword Type '") & FieldToUpdate) + "' could not be found on the Keyword Record Type 'Singer Information'")
                End If
                ' Create a keyword of this type. Use the TryCreateKeyword extension method.(NewValue is passed in).
                Dim newKeywordValue As Keyword = Nothing
                If Not keyType.TryCreateKeyword(NewValue, newKeywordValue) Then
                    Throw New Exception((Convert.ToString("Keyword for ") & NewValue) + " could not be created.")
                End If
                ' Get the document from the core. Check for null.
                Dim doc As Document = app.Core.GetDocumentByID(DocumentID)
                If doc Is Nothing Then
                    Throw New Exception("The document was not found.")
                End If
                ' Create the KeywordModifier from the document.
                Dim keywordMod As KeywordModifier = doc.CreateKeywordModifier()
                ' Find all of the Keyword Records on the document that have the keyword record type. (KeywordRecordList)(FindAll)
                Dim keyRecList As KeywordRecordList = doc.KeywordRecords.FindAll(keyRecType)
                ' Loop through all of the keyword records in this list.
                For Each keyRec As KeywordRecord In keyRecList
                    ' Find the keyword in the record for "SSN".
                    Dim key As Keyword = keyRec.Keywords.Find("SSN")
                    ' If the keyword is not null AND the keyword is not blank AND the keyword alphanumeric value is equal to SSN (passed in from method).
                    If (key IsNot Nothing) AndAlso (Not key.IsBlank) AndAlso (key.AlphaNumericValue = SSNValue) Then
                    ' Create the EditableKeywordRecord from the KeywordRecord.
                    Dim editableKeyRec As EditableKeywordRecord = keyRec.CreateEditableKeywordRecord()
                        ' Find the old keyword for the keyword type from the record.
                        Dim oldKeyword As Keyword = keyRec.Keywords.Find(keyType)
                        ' Update the keyword within the editablekeywordrecord.
                        editableKeyRec.UpdateKeyword(oldKeyword, newKeywordValue)
                        ' Update the Keyword Record for the Keyword Modifier.
                        keywordMod.UpdateKeywordRecord(editableKeyRec)
                    End If
                Next
                ' Lock the document. (Use a using statement to clean up lock.)
                Using documentLock As DocumentLock = doc.LockDocument()
                    ' Check if the lock status is Already Locked (DocumentLockStatus enum).
                    If documentLock.Status = DocumentLockStatus.AlreadyLocked Then
                        Throw New Exception("Document lock could not be obtained, lock obtained by another user or process.")
                    End If
                    ' If not locked, apply the changes to the database.
                    keywordMod.ApplyChanges()

                End Using

            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Sub


        Public Sub New(app As Hyland.Unity.Application)
            If app Is Nothing Then
                Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
            End If
            Me.app = app
        End Sub
End Class