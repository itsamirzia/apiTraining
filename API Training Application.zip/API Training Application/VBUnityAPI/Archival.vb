﻿
Imports System.Collections.Generic
Imports Hyland.Unity.Extensions
Imports Hyland.Unity
Imports Hyland.Unity.UnityForm

Public Class Archival
        Private app As Hyland.Unity.Application = Nothing

        Public Function StoreNewLoanDocument(FilePath As String, AccountNum As String, LoanAmount As String, Signer1Info As List(Of Keyword), Signer2Info As List(Of Keyword)) As Long
            Try
                Dim newDocID As Long = -1
                ' Create the PageData from the file path. (Use a using statement).
                Using pageData As PageData = app.Core.Storage.CreatePageData(FilePath)
                    ' Find the DocumentType for "Loan Application". Check for null.
                    Dim documentType As DocumentType = app.Core.DocumentTypes.Find("Loan Application")
                    If documentType Is Nothing Then
                        Throw New Exception("Could not find document type: Loan Application")
                    End If
                    ' Find the FileType for "Image File format". Check for null.
                    Dim imageFileType As FileType = app.Core.FileTypes.Find("Image File Format")
                    'or search for 2
                    If imageFileType Is Nothing Then
                        Throw New Exception("Could not find file format: Image File Format")
                    End If
                    ' Create the StoreNewDocumentProperties object.
                    Dim newDocProps As StoreNewDocumentProperties = app.Core.Storage.CreateStoreNewDocumentProperties(documentType, imageFileType)
                    ' Find the keyword type for "Loan Account #". Check for null.
                    Dim loanAcctNumKeyType As KeywordType = app.Core.KeywordTypes.Find("Loan Account #")
                    If loanAcctNumKeyType Is Nothing Then
                        Throw New Exception("Could not find keyword type: Loan Account #")
                    End If
                    ' Create a keyword of this type. Use the TryCreateKeyword extension method. The AccountNum is passed into the method.
                    Dim accountNumKeyword As Keyword = Nothing
                    If Not loanAcctNumKeyType.TryCreateKeyword(AccountNum, accountNumKeyword) Then
                        Throw New Exception("Account number keyword could not be created.")
                    End If
                    ' Add the new keyword to our properties.
                    newDocProps.AddKeyword(accountNumKeyword)
                    ' Find the keyword type for "Loan Amount". Check for null.
                    Dim loanAmtKeyType As KeywordType = app.Core.KeywordTypes.Find("Loan Amount")
                    If loanAmtKeyType Is Nothing Then
                        Throw New Exception("Could not find keyword type: Loan Amount")
                    End If
                    ' Create a keyword of this type. Use the TryCreateKeyword extension method. The LoanAmount is passed into the method.
                    Dim loanAmtKeyword As Keyword = Nothing
                    If Not loanAmtKeyType.TryCreateKeyword(LoanAmount, loanAmtKeyword) Then
                        Throw New Exception("Loan amount number keyword could not be created.")
                    End If
                    ' Add the new keyword to our properties.
                    newDocProps.AddKeyword(loanAmtKeyword)
                    ' Find keyword record type for "Signer Information" Check for null.
                    Dim keyRecType As KeywordRecordType = app.Core.KeywordRecordTypes.Find("Signer Information")
                    If keyRecType Is Nothing Then
                        Throw New Exception("Keyword Record type not found.")
                    End If
                    ' Create editable keyword record 1 from keyword record type.
                    Dim ekr1 As EditableKeywordRecord = keyRecType.CreateEditableKeywordRecord()
                    ' foreach keyword in Signer1Info keyword list, add the keyword to the editable keyword record
                    For Each key As Keyword In Signer1Info
                        ekr1.AddKeyword(key)
                    Next
                    ' Add the editable keyword record 1 to the new document properties. 
                    newDocProps.AddKeywordRecord(ekr1)
                    ' Create editable keyword record 2 from keyword record type.
                    Dim ekr2 As EditableKeywordRecord = keyRecType.CreateEditableKeywordRecord()
                    ' foreach keyword in Signer2Info keyword list, add the keyword to the editable keyword record
                    For Each key As Keyword In Signer2Info
                        ekr2.AddKeyword(key)
                    Next
                    ' Add the editable keyword record 2 to the new document properties. 
                    newDocProps.AddKeywordRecord(ekr2)
                    ' Create the new document.
                    Dim newDocument As Document = app.Core.Storage.StoreNewDocument(pageData, newDocProps)
                    ' Set the newDocID to the ID of the newly imported document. 
                    newDocID = newDocument.ID

                    Return newDocID
                End Using

            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Function


        Public Function StoreNewUserUnityForm(FullName As String, ManagerName As String) As Long
            Dim newDocID As Long = -1
            Try
                ' Find the Unity form Template for "New User Request Form". Check for null.
                Dim newUserTemplate As FormTemplate = app.Core.UnityFormTemplates.Find("New User Request Form")
                If newUserTemplate Is Nothing Then
                    Throw New Exception("Could not find the unity template with name: New User Request Form")
                End If
                ' Create the StoreNewUnityFormProperties object.
                Dim unityFormProps As StoreNewUnityFormProperties = app.Core.Storage.CreateStoreNewUnityFormProperties(newUserTemplate)
                ' Find the KeywordType for "Full Name". Check for null.
                Dim fullNameKeywordType As KeywordType = app.Core.KeywordTypes.Find("Full Name")

                If fullNameKeywordType Is Nothing Then
                    Throw New Exception("Could not find the keyword type with name: Full Name")
                End If
                ' Create a keyword for this type. Use the TryCreateKeyword extension method. The FullName value is passed into this method.
                Dim fullNameKeyword As Keyword = Nothing
                If Not fullNameKeywordType.TryCreateKeyword(FullName, fullNameKeyword) Then
                    Throw New Exception("Could not create the full name keyword.")
                End If
                ' Add the full name keyword to our properties.
                unityFormProps.AddKeyword(fullNameKeyword)
                ' Find the KeywordType for "Manager Name". Check for null.
                Dim managerNameKeyType As KeywordType = app.Core.KeywordTypes.Find("Manager Name")
                If managerNameKeyType Is Nothing Then
                    Throw New Exception("Could not find the keyword type with name: Manager Name")
                End If
                ' Create a keyword for this type. Use the TryCreateKeyword extension method. The ManagerName value is passed into this method.
                Dim managerNameKey As Keyword = Nothing
                If Not managerNameKeyType.TryCreateKeyword(ManagerName, managerNameKey) Then
                    Throw New Exception("Could not create the manager name keyword.")
                End If
                ' Add the manager name keyword to our properties. 
                unityFormProps.AddKeyword(managerNameKey)
                ' Archive the Unity Form.
                Dim newUnityFormDocument As Document = app.Core.Storage.StoreNewUnityForm(unityFormProps)
                ' Set the newDocID. 
                newDocID = newUnityFormDocument.ID
            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
            Return newDocID
        End Function

        Public Sub New(app As Hyland.Unity.Application)
            If app Is Nothing Then
                Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
            End If
            Me.app = app
        End Sub
End Class