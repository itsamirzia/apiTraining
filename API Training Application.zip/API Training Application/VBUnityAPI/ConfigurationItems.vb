﻿
Imports Hyland.Unity
Public Class ConfigurationItems
    Private app As Hyland.Unity.Application = Nothing

    Public Function GetDocumentTypes() As List(Of String)
        Try
            Dim docTypes As New List(Of String)()
            ' Loop through all of the Document Types the current user can access. DocumentTypes are accessed through the Core. The Core is accessed from the Application object.
            For Each docType As DocumentType In app.Core.DocumentTypes
                ' Add the document type names to the generic list of strings.
                docTypes.Add(docType.Name)
            Next
            Return docTypes
        Catch ex As SessionNotFoundException
            app.Diagnostics.Write(ex)
            Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
        Catch ex As UnityAPIException
            app.Diagnostics.Write(ex)
            Throw New Exception("There was a Unity API exception.", ex)
        Catch ex As Exception
            app.Diagnostics.Write(ex)
            Throw New Exception("There was an unknown exception.", ex)
        End Try
    End Function

    Public Sub New(app As Hyland.Unity.Application)
        If app Is Nothing Then
            Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
        End If
        Me.app = app
    End Sub
End Class

