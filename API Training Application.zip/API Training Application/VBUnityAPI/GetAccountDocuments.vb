﻿
Imports Hyland.Unity

Public Class GetAccountDocuments
        Private app As Hyland.Unity.Application = Nothing

        Public Function GetDocumentsForAccount(DocumentTypeName As String, AccountNum As String) As DocumentList
            Try
                ' Find the DocumentType for DocumentTypeName (passed into method). Check for null.
                Dim docType As DocumentType = app.Core.DocumentTypes.Find(DocumentTypeName)
                If docType Is Nothing Then
                    Throw New Exception((Convert.ToString("Document Type '") & DocumentTypeName) + "' not found.")
                End If
                ' Create the DocumentQuery object.
                Dim docQuery As DocumentQuery = app.Core.CreateDocumentQuery()
                ' Add the DocumentType to the document query.
                docQuery.AddDocumentType(docType)
            'Add the "Loan Account #" keyword to search for. The Loan Account # value is passed into method. Be sure to use equal operator and the 'or' relation.
            docQuery.AddKeyword("Loan Account #", AccountNum, KeywordOperator.Equal, KeywordRelation.[Or])
            ' Execute the Query.
            Dim documents As DocumentList = docQuery.Execute(1000)
                Return documents
            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Function

        Public Sub New(app As Hyland.Unity.Application)
            If app Is Nothing Then
                Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
            End If
            Me.app = app
        End Sub
End Class