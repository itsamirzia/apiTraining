﻿
Imports Hyland.Unity
Imports System.IO

Public Class SaveOutDocument
        Private app As Hyland.Unity.Application = Nothing

        Public Sub SaveDocument(document As Document, providerName As String)
            Try
                Select Case providerName
                    Case "Default"
                        ' Get the default data provider. This will come from the Retrieval class. 
                        Dim defaultDataProvider As DefaultDataProvider = app.Core.Retrieval.[Default]
                        ' Use a using statement to get the PageData (for cleanup), and then save the document to disk. To Save, use the Save method above.
                        Using pageData As PageData = defaultDataProvider.GetDocument(document.DefaultRenditionOfLatestRevision)
                            'Call the Save Method
                            Save(pageData, document, providerName)
                        End Using
                        Exit Select
                    Case "Native"
                        Dim nativeProvider As NativeDataProvider = app.Core.Retrieval.Native
                        Using pageData As PageData = nativeProvider.GetDocument(document.DefaultRenditionOfLatestRevision)
                            Save(pageData, document, providerName)
                        End Using
                        Exit Select
                    Case "Image"
                        Dim imageProvider As ImageDataProvider = app.Core.Retrieval.Image
                        Using pageData As PageData = imageProvider.GetDocument(document.DefaultRenditionOfLatestRevision)
                            Save(pageData, document, providerName)
                        End Using
                        Exit Select
                    Case "PDF"
                        Dim pdfProvider As PDFDataProvider = app.Core.Retrieval.PDF
                        Using pageData As PageData = pdfProvider.GetDocument(document.DefaultRenditionOfLatestRevision)
                            Save(pageData, document, providerName)
                        End Using
                        Exit Select
                    Case "Text"
                        Dim textProvider As TextDataProvider = app.Core.Retrieval.Text
                        Using pageData As PageData = textProvider.GetDocument(document.DefaultRenditionOfLatestRevision)
                            Save(pageData, document, providerName)
                        End Using
                        Exit Select
                End Select
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Sub

        Private Sub Save(pageData As PageData, document As Document, providerName As String)
            ' Create the file path of where we want to save the document. This is completed for you.
            Dim filePath As String = (Convert.ToString("C:\" + document.ID.ToString() + "-") & providerName) + "." + pageData.Extension
            If File.Exists(filePath) Then
                File.Delete(filePath)
            End If

            ' Save the file to disk. We will want to use the Utility class. 
            Utility.WriteStreamToFile(pageData.Stream, filePath)

        End Sub


        Public Sub New(app As Hyland.Unity.Application)
            If app Is Nothing Then
                Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
            End If
            Me.app = app
        End Sub

End Class