﻿Imports Hyland.Unity

Public Class ValidateKeywords
    Private app As Hyland.Unity.Application = Nothing

    Public Function AmountAboveThreshold(DocumentID As Long) As Boolean
        Try
            Dim isAmountAboveThreshold As Boolean = False

            ' Get the Document using the ID that is passed into the method. (Core). Check for null.
            Dim doc As Document = app.Core.GetDocumentByID(DocumentID)
            If doc Is Nothing Then
                Throw New Exception("Could not find document with id: " + DocumentID)
            End If
            ' Get all of the Keyword Records from the document.
            Dim keyRecList As KeywordRecordList = doc.KeywordRecords
            ' Loop through the KeywordRecords on the document.
            For Each rec As KeywordRecord In keyRecList
                ' Loop through each keyword in the keyword record
                For Each key As Keyword In rec.Keywords
                    ' Check if the KeywordType name for the current keyword is "Loan Amount".
                    If key.KeywordType.Name = "Loan Amount" Then
                        ' If so, check if the value of loan amount is greater than 10,000. (x>10000)
                        If key.CurrencyValue > 10000 Then
                            ' If so, set isAmountAboveThreshold to true. 
                            isAmountAboveThreshold = True
                        End If
                    End If
                Next
            Next

            Return isAmountAboveThreshold


        Catch ex As SessionNotFoundException
            app.Diagnostics.Write(ex)
            Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
        Catch ex As UnityAPIException
            app.Diagnostics.Write(ex)
            Throw New Exception("There was a Unity API exception.", ex)
        Catch ex As Exception
            app.Diagnostics.Write(ex)
            Throw New Exception("There was an unknown exception.", ex)
        End Try


    End Function

    Public Function SignerInfoMissing(DocumentID As Long) As Integer
        Try
            Dim numRecordsInvalid As Integer = 0
            ' Get the Document from the Core. Check for null.
            Dim doc As Document = app.Core.GetDocumentByID(DocumentID)
            If doc Is Nothing Then
                Throw New Exception("Could not find document with id: " + DocumentID)
            End If
            ' Loop through the Keyword Records on the document.
            For Each keyRec As KeywordRecord In doc.KeywordRecords
                ' Check if the KeywordRecordType RecordType is MultiInstance and check that KeywordRecordType name is "Signer Information".
                If (keyRec.KeywordRecordType.RecordType = RecordType.MultiInstance) AndAlso (keyRec.KeywordRecordType.Name = "Signer Information") Then
                    ' If so, loop through each Keyword in the record. 
                    For Each key As Keyword In keyRec.Keywords
                        ' Check if the keyword IsBlank.
                        If key.IsBlank Then
                            ' If so, increment the numRecordsInvalid.
                            numRecordsInvalid += 1
                        End If
                    Next
                End If
            Next
            Return numRecordsInvalid
        Catch ex As SessionNotFoundException
            app.Diagnostics.Write(ex)
            Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
        Catch ex As UnityAPIException
            app.Diagnostics.Write(ex)
            Throw New Exception("There was a Unity API exception.", ex)
        Catch ex As Exception
            app.Diagnostics.Write(ex)
            Throw New Exception("There was an unknown exception.", ex)
        End Try
    End Function


    Public Sub New(app As Hyland.Unity.Application)
        If app Is Nothing Then
            Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
        End If

        Me.app = app
    End Sub
End Class
