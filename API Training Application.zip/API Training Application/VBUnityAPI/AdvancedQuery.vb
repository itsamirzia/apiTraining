﻿
Imports System.Collections.Generic
Imports System.Data

Imports Hyland.Unity

Public Class AdvancedQuery
        Private app As Hyland.Unity.Application = Nothing
        Private resultsTable As New DataTable("QueryResults")
        Private resultsTable2 As New DataTable("QueryResults")

        Public Function AdvancedDocumentQuery(CustomQueryName As String, keywordList As List(Of Keyword)) As DataTable
            Try
                ' Find the custom query and check for null.
                Dim custQuery As CustomQuery = app.Core.CustomQueries.Find(CustomQueryName)
                If custQuery Is Nothing Then
                    Throw New Exception("Custom Query not found")
                End If

                ' Create the document query.
                Dim dq As DocumentQuery = app.Core.CreateDocumentQuery()
                ' Add the custom query to the document query.
                dq.AddCustomQuery(custQuery)
                ' Loop through the keywords in the list and add them to the query. These keywords have the same type so be sure to use the Or relation.
                For Each key As Keyword In keywordList
                    dq.AddKeyword(key, KeywordOperator.Equal, KeywordRelation.[Or])
                Next
                ' Execute the Query
                Dim queryResult As QueryResult = dq.ExecuteQueryResults(1000)

            ' Loop through display column configurations and add columns to data table.
            For Each dispColConfig As DisplayColumnConfiguration In queryResult.DisplayColumnConfigurations
                    Dim heading As String = dispColConfig.Heading
                    ' Get Heading Value
                    resultsTable.Columns.Add(heading)
                Next

            ' Loop through the results to add rows to the data table.
            For Each resultItem As QueryResultItem In queryResult.QueryResultItems
                    Dim row As DataRow = resultsTable.NewRow()
                    For Each dispCol As DisplayColumn In resultItem.DisplayColumns
                        Dim rowValue As String = dispCol.ToString()
                        ' Get Row Value
                        row(dispCol.Configuration.Heading) = rowValue
                    Next
                    resultsTable.Rows.Add(row)
                Next
                Return resultsTable

            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Function

        Public Function AdvancedDocumentQuery(DocumentTypeName As String, StandAloneKeywords As List(Of Keyword), Signer1Info As List(Of Keyword), Signer2Info As List(Of Keyword)) As DataTable
            Try
                ' Find the DocumentType and check for null. (DocumentTypeName is passed into this method.)
                Dim docType As DocumentType = app.Core.DocumentTypes.Find(DocumentTypeName)
                If docType Is Nothing Then
                    Throw New Exception("Document Type not found")
                End If
                ' Create the document query.
                Dim dq As DocumentQuery = app.Core.CreateDocumentQuery()
                ' Add the DocType to the document query.
                dq.AddDocumentType(docType)
                ' Loop through the standalone keywords in the list and add them to the query. These keywords have the same type so be sure to use the Or relation.
                For Each keyword As Keyword In StandAloneKeywords
                    dq.AddKeyword(keyword, KeywordOperator.Equal, KeywordRelation.[Or])
                Next
                ' Find the KeywordRecordType for "Signer Information". Check for null.
                Dim keyRecType As KeywordRecordType = app.Core.KeywordRecordTypes.Find("Signer Information")
                If keyRecType Is Nothing Then
                    Throw New Exception("The keyword record type could not be found.")
                End If
                ' Create the QueryKeywordRecord from the KeywordRecordType.
                Dim queryKeyRecSigner1 As QueryKeywordRecord = keyRecType.CreateQueryKeywordRecord()
                ' Loop through Signer1Info and add the keywords to the QueryKeyword record.
                For Each keyword As Keyword In Signer1Info
                    queryKeyRecSigner1.AddKeyword(keyword)
                Next
                ' Add the query keyword record to the document query. Be sure to use OR operation.
                dq.AddQueryKeywordRecord(queryKeyRecSigner1, KeywordRelation.[Or])
                ' Create a second instance of QueryKeywordRecord from the KeywordRecordType.
                Dim queryKeyRecSigner2 As QueryKeywordRecord = keyRecType.CreateQueryKeywordRecord()
                ' Loop through Signer2Info and add the keywords to the second instance of our QueryKeyword record.
                For Each keyword As Keyword In Signer2Info
                    queryKeyRecSigner2.AddKeyword(keyword)
                Next
                ' Add the second query keyword record to the document query. There are no more query keyword records so an operator is not required.
                dq.AddQueryKeywordRecord(queryKeyRecSigner2)
                ' Add DisplayColumn to doc query for Document ID.
                dq.AddDisplayColumn(DisplayColumnType.DocumentID)
                ' Add DisplayColumn to doc query for Document Type Name.
                dq.AddDisplayColumn(DisplayColumnType.DocumentTypeName)
                ' Add DisplayColumn to doc query for Document Name.
                dq.AddDisplayColumn(DisplayColumnType.DocumentName)
                ' Find the keyword type for "Loan Account #". Check for null.
                Dim loanAccountKeyType As KeywordType = app.Core.KeywordTypes.Find("Loan Account #")
                If loanAccountKeyType Is Nothing Then
                    Throw New Exception("Could not find keyword type: Loan Account #")
                End If
                ' Add the keyword type display column to the document query.
                dq.AddDisplayColumn(loanAccountKeyType)
                'add a keyword display column
                'Execute Query
                Dim queryResult As QueryResult = dq.ExecuteQueryResults(1000)

            ' Loop through display column configuration and add columns to data table.
            For Each dispColConfig As DisplayColumnConfiguration In queryResult.DisplayColumnConfigurations
                    Dim heading As String = dispColConfig.Heading
                    ' Get Heading Value
                    resultsTable2.Columns.Add(heading)
                Next

                ' Loop through the results to add rows to the data table.
                For Each resultItem As QueryResultItem In queryResult.QueryResultItems
                    Dim row As DataRow = resultsTable2.NewRow()
                    For Each dispCol As DisplayColumn In resultItem.DisplayColumns
                        Dim rowValue As String = dispCol.ToString()
                        ' Get Row Value
                        ' long docID = resultItem.Document.ID; // Get Document Handle
                        row(dispCol.Configuration.Heading) = rowValue
                    Next
                    resultsTable2.Rows.Add(row)
                Next
                Return resultsTable2


            Catch ex As SessionNotFoundException
                app.Diagnostics.Write(ex)
                Throw New Exception("The Unity API session could not be found, please reconnect.", ex)
            Catch ex As UnityAPIException
                app.Diagnostics.Write(ex)
                Throw New Exception("There was a Unity API exception.", ex)
            Catch ex As Exception
                app.Diagnostics.Write(ex)
                Throw New Exception("There was an unknown exception.", ex)
            End Try
        End Function

        Public Sub New(app As Hyland.Unity.Application)
            If app Is Nothing Then
                Throw New ArgumentNullException("app", "The Unity application object is null, make sure to connect first.")
            End If
            Me.app = app
        End Sub
End Class