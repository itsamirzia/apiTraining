﻿using System;
using Hyland.Unity;

namespace UnityAPI
{
	public class GetAccountDocuments
	{
		private Hyland.Unity.Application app = null;

		public DocumentList GetDocumentsForAccount(string DocumentTypeName, string AccountNum)
		{
			try
			{
                // Find the DocumentType for DocumentTypeName (passed into method). Check for null.
                DocumentType docType = app.Core.DocumentTypes.Find(DocumentTypeName);
                if (docType == null)
                {
                    throw new Exception("Document Type '" + DocumentTypeName + "' not found.");
                }
                // Create the DocumentQuery object.
                DocumentQuery docQuery = app.Core.CreateDocumentQuery();
                // Add the DocumentType to the document query.
                docQuery.AddDocumentType(docType);
                // Add the "Loan Account #" keyword to search for. The Loan Account # value is passed into method. Be sure to use the equal operator and 'or' relation.
                docQuery.AddKeyword("Loan Account #", AccountNum,KeywordOperator.Equal,KeywordRelation.Or);
                // Execute the Query.
                DocumentList documents = docQuery.Execute(1000);
                return documents;
			}
			catch (SessionNotFoundException ex)
			{
				app.Diagnostics.Write(ex);
				throw new Exception("The Unity API session could not be found, please reconnect.", ex);
			}
			catch (UnityAPIException ex)
			{
				app.Diagnostics.Write(ex);
				throw new Exception("There was a Unity API exception.", ex);
			}
			catch (Exception ex)
			{
				app.Diagnostics.Write(ex);
				throw new Exception("There was an unknown exception.", ex);
			}
		}

		public GetAccountDocuments(Hyland.Unity.Application app)
		{
			if (app == null)
			{
				throw new ArgumentNullException("app", "The Unity application object is null, make sure to connect first.");
			}
			this.app = app;
		}
	}
}
