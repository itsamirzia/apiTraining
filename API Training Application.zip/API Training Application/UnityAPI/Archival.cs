﻿using System;
using System.Collections.Generic;
using Hyland.Unity.Extensions;
using Hyland.Unity;
using Hyland.Unity.UnityForm;

namespace UnityAPI
{
    public class Archival
    {
        private Hyland.Unity.Application app = null;

        public long StoreNewLoanDocument(string FilePath, string AccountNum, string LoanAmount, List<Keyword> Signer1Info, List<Keyword> Signer2Info)
        {
            try
            {
                long newDocID = -1;
                // Create the PageData from the file path. (Use a using statement).
                using (PageData pageData = app.Core.Storage.CreatePageData(FilePath))
                {
                    // Find the DocumentType for "Loan Application". Check for null.
                    DocumentType documentType = app.Core.DocumentTypes.Find("Loan Application");
                    if (documentType == null)
                    {
                        throw new Exception("Could not find document type: Loan Application");
                    }
                    // Find the FileType for "Image File format". Check for null.
                    FileType imageFileType = app.Core.FileTypes.Find("Image File Format"); //or search for 2
                    if (imageFileType == null)
                    {
                        throw new Exception("Could not find file format: Image File Format");
                    }
                    // Create the StoreNewDocumentProperties object.
                    StoreNewDocumentProperties newDocProps = app.Core.Storage.CreateStoreNewDocumentProperties(documentType, imageFileType);
                    // Find the keyword type for "Loan Account #". Check for null.
                    KeywordType loanAcctNumKeyType = app.Core.KeywordTypes.Find("Loan Account #");
                    if (loanAcctNumKeyType == null)
                    {
                        throw new Exception("Could not find keyword type: Loan Account #");
                    }
                    // Create a keyword of this type. Use the TryCreateKeyword extension method. The AccountNum is passed into the method.
                    Keyword accountNumKeyword = null;
                    if (!loanAcctNumKeyType.TryCreateKeyword(AccountNum, out accountNumKeyword))
                    {
                        throw new Exception("Account number keyword could not be created.");
                    }
                    // Add the new keyword to our properties.
                    newDocProps.AddKeyword(accountNumKeyword);
                    // Find the keyword type for "Loan Amount". Check for null.
                    KeywordType loanAmtKeyType = app.Core.KeywordTypes.Find("Loan Amount");
                    if (loanAmtKeyType == null)
                    {
                        throw new Exception("Could not find keyword type: Loan Amount");
                    }
                    // Create a keyword of this type. Use the TryCreateKeyword extension method. The LoanAmount is passed into the method.
                    Keyword loanAmtKeyword = null;
                    if (!loanAmtKeyType.TryCreateKeyword(LoanAmount, out loanAmtKeyword))
                    {
                        throw new Exception("Loan amount number keyword could not be created.");
                    }
                    // Add the new keyword to our properties.
                    newDocProps.AddKeyword(loanAmtKeyword);
                    // Find keyword record type for "Signer Information" Check for null.
                    KeywordRecordType keyRecType = app.Core.KeywordRecordTypes.Find("Signer Information");
                    if (keyRecType == null)
                    {
                        throw new Exception("Keyword Record type not found.");
                    }
                    // Create editable keyword record 1 from keyword record type.
                    EditableKeywordRecord ekr1 = keyRecType.CreateEditableKeywordRecord();
                    // foreach keyword in Signer1Info keyword list, add the keyword to the editable keyword record
                    foreach (Keyword key in Signer1Info)
                    {
                        ekr1.AddKeyword(key);
                    }
                    // Add the editable keyword record 1 to the new document properties. 
                    newDocProps.AddKeywordRecord(ekr1);
                    // Create editable keyword record 2 from keyword record type.
                    EditableKeywordRecord ekr2 = keyRecType.CreateEditableKeywordRecord();
                    // foreach keyword in Signer2Info keyword list, add the keyword to the editable keyword record
                    foreach (Keyword key in Signer2Info)
                    {
                        ekr2.AddKeyword(key);
                    }
                    // Add the editable keyword record 2 to the new document properties. 
                    newDocProps.AddKeywordRecord(ekr2);
                    // Create the new document.
                    Document newDocument = app.Core.Storage.StoreNewDocument(pageData, newDocProps);
                    // Set the newDocID to the ID of the newly imported document. 
                    newDocID = newDocument.ID;

                    return newDocID;
                }
            }

            catch (SessionNotFoundException ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("The Unity API session could not be found, please reconnect.", ex);
            }
            catch (UnityAPIException ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("There was a Unity API exception.", ex);
            }
            catch (Exception ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("There was an unknown exception.", ex);
            }
        }


        public long StoreNewUserUnityForm(string FullName, string ManagerName)
        {
            long newDocID = -1;
            try
            {
                // Find the Unity form Template for "New User Request Form". Check for null.
                FormTemplate newUserTemplate = app.Core.UnityFormTemplates.Find("New User Request Form");
                if (newUserTemplate == null)
                {
                    throw new Exception("Could not find the unity template with name: New User Request Form");
                }
                // Create the StoreNewUnityFormProperties object.
                StoreNewUnityFormProperties unityFormProps = app.Core.Storage.CreateStoreNewUnityFormProperties(newUserTemplate);
                // Find the KeywordType for "Full Name". Check for null.
                KeywordType fullNameKeywordType = app.Core.KeywordTypes.Find("Full Name");

                if (fullNameKeywordType == null)
                {
                    throw new Exception("Could not find the keyword type with name: Full Name");
                }
                // Create a keyword for this type. Use the TryCreateKeyword extension method. The FullName value is passed into this method.
                Keyword fullNameKeyword = null;
                if (!fullNameKeywordType.TryCreateKeyword(FullName, out fullNameKeyword))
                {
                    throw new Exception("Could not create the full name keyword.");
                }
                // Add the full name keyword to our properties.
                unityFormProps.AddKeyword(fullNameKeyword);
                // Find the KeywordType for "Manager Name". Check for null.
                KeywordType managerNameKeyType = app.Core.KeywordTypes.Find("Manager Name");
                if (managerNameKeyType == null)
                {
                    throw new Exception("Could not find the keyword type with name: Manager Name");
                }
                // Create a keyword for this type. Use the TryCreateKeyword extension method. The ManagerName value is passed into this method.
                Keyword managerNameKey = null;
                if (!managerNameKeyType.TryCreateKeyword(ManagerName, out managerNameKey))
                {
                    throw new Exception("Could not create the manager name keyword.");
                }
                // Add the manager name keyword to our properties. 
                unityFormProps.AddKeyword(managerNameKey);
                // Archive the Unity Form.
                Document newUnityFormDocument = app.Core.Storage.StoreNewUnityForm(unityFormProps);
                // Set the newDocID. 
                newDocID = newUnityFormDocument.ID;
            }
            catch (SessionNotFoundException ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("The Unity API session could not be found, please reconnect.", ex);
            }
            catch (UnityAPIException ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("There was a Unity API exception.", ex);
            }
            catch (Exception ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("There was an unknown exception.", ex);
            }
            return newDocID;
        }

        public Archival(Hyland.Unity.Application app)
        {
            if (app == null)
            {
                throw new ArgumentNullException("app", "The Unity application object is null, make sure to connect first.");
            }
            this.app = app;
        }
    }
}
