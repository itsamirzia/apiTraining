﻿using System;
using Hyland.Unity;
using System.IO;

namespace UnityAPI
{
    public class SaveOutDocument
    {
        private Hyland.Unity.Application app = null;
        
        public void SaveDocument(Document document, string providerName)
        {
            try
            {            
                switch (providerName)
                {
                    case "Default":
                        // Get the default data provider. This will come from the Retrieval class. 
                        DefaultDataProvider defaultDataProvider = app.Core.Retrieval.Default;
                        // Use a using statement to get the PageData (for cleanup), and then save the document to disk. To Save, use the Save method above.
                        using (PageData pageData = defaultDataProvider.GetDocument(document.DefaultRenditionOfLatestRevision))
                        {
                            //Call the Save Method
                            Save(pageData, document, providerName);
                        }
                        break;
                    case "Native":
                        NativeDataProvider nativeProvider = app.Core.Retrieval.Native;
                        using (PageData pageData = nativeProvider.GetDocument(document.DefaultRenditionOfLatestRevision))
                        {
                            Save(pageData, document, providerName);
                        }
                        break;
                    case "Image":
                        ImageDataProvider imageProvider = app.Core.Retrieval.Image;
                        using (PageData pageData = imageProvider.GetDocument(document.DefaultRenditionOfLatestRevision))
                        {
                            Save(pageData, document, providerName);
                        }
                        break;
                    case "PDF":
                        PDFDataProvider pdfProvider = app.Core.Retrieval.PDF;
                        using (PageData pageData = pdfProvider.GetDocument(document.DefaultRenditionOfLatestRevision))
                        {
                            Save(pageData, document, providerName);
                        }
                        break;
                    case "Text":
                        TextDataProvider textProvider = app.Core.Retrieval.Text;
                        using (PageData pageData = textProvider.GetDocument(document.DefaultRenditionOfLatestRevision))
                        {
                            Save(pageData, document, providerName);
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                app.Diagnostics.Write(ex);
                throw new Exception("There was an unknown exception.", ex);
            }
        }

        private void Save(PageData pageData, Document document, string providerName)
        {
            // Create the file path of where we want to save the document. This is completed for you.
            string filePath = @"C:\" + document.ID.ToString() + "-" + providerName + "." + pageData.Extension;
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }

            // Save the file to disk. We will want to use the Utility class. 
            Utility.WriteStreamToFile(pageData.Stream, filePath);

        }


        public SaveOutDocument(Hyland.Unity.Application app)
        {
            if (app == null)
            {
                throw new ArgumentNullException("app", "The Unity application object is null, make sure to connect first.");
            }
            this.app = app;
        }

    }
}
